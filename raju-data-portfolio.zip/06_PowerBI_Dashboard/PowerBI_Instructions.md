# Power BI Dashboard

Instructions to create the dashboard